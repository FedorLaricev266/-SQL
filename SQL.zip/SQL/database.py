import sqlite3
from contextlib import contextmanager

@contextmanager
def get_db_connection():
    conn = sqlite3.connect("test.db")
    conn.row_factory = sqlite3.Row  # Чтобы получать данные как словари
    try:
        yield conn
    finally:
        conn.close()

def init_database():
    with get_db_connection() as conn:
        cursor = conn.cursor()
        
        # Создаем тестовые таблицы
        cursor.executescript('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT UNIQUE,
                age INTEGER,
                city TEXT
            );
            
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                price REAL,
                category TEXT
            );
            
            CREATE TABLE IF NOT EXISTS orders (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                product_id INTEGER,
                quantity INTEGER,
                order_date DATE,
                FOREIGN KEY (user_id) REFERENCES users (id),
                FOREIGN KEY (product_id) REFERENCES products (id)
            );
        ''')
        
        # Добавляем тестовые данные
        cursor.executescript('''
            INSERT OR IGNORE INTO users (name, email, age, city) VALUES 
            ('Иван Иванов', 'ivan@mail.ru', 25, 'Москва'),
            ('Петр Петров', 'petr@yandex.ru', 30, 'Санкт-Петербург'),
            ('Мария Сидорова', 'maria@gmail.com', 22, 'Москва');
            
            INSERT OR IGNORE INTO products (name, price, category) VALUES 
            ('Ноутбук', 50000.0, 'Электроника'),
            ('Смартфон', 30000.0, 'Электроника'),
            ('Книга', 500.0, 'Книги'),
            ('Кофе', 350.0, 'Продукты');
            
            INSERT OR IGNORE INTO orders (user_id, product_id, quantity, order_date) VALUES 
            (1, 1, 1, '2024-01-15'),
            (1, 3, 2, '2024-01-16'),
            (2, 2, 1, '2024-01-17'),
            (3, 4, 5, '2024-01-18');
        ''')
        
        conn.commit()

def execute_sql_query(sql_query):
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(sql_query)
            
            if sql_query.strip().upper().startswith('SELECT'):
                results = cursor.fetchall()
                columns = [description[0] for description in cursor.description]
                return {
                    "success": True,
                    "columns": columns,
                    "data": [dict(row) for row in results],
                    "rowcount": len(results)
                }
            else:
                conn.commit()
                return {
                    "success": True,
                    "message": f"Запрос выполнен успешно. Затронуто строк: {cursor.rowcount}",
                    "rowcount": cursor.rowcount
                }
                
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }

def get_table_structure():
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = cursor.fetchall()
        
        structure = {}
        for table in tables:
            table_name = table[0]
            cursor.execute(f"PRAGMA table_info({table_name})")
            columns = cursor.fetchall()
            structure[table_name] = columns
            
        return structure