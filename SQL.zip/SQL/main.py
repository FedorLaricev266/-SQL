from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
import database

app = FastAPI(title="SQL Learning Platform")

# Инициализация базы данных при запуске
database.init_database()

# Настройка шаблонов
templates = Jinja2Templates(directory="templates")

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    structure = database.get_table_structure()
    return templates.TemplateResponse("index.html", {
        "request": request,
        "structure": structure
    })

@app.get("/execute", response_class=HTMLResponse)
async def execute_page(request: Request):
    return templates.TemplateResponse("execute.html", {"request": request})

@app.post("/execute", response_class=HTMLResponse)
async def execute_sql(
    request: Request,
    sql_query: str = Form(...)
):
    result = database.execute_sql_query(sql_query)
    return templates.TemplateResponse("results.html", {
        "request": request,
        "sql_query": sql_query,
        "result": result
    })

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)